clear all;
clc;
%read data

data = xlsread('SX5E_Impliedvols.xlsx');
% take the date column starting at T = 0 
T = [0 data(1,2:end)];
% take data vol
data_vol = data(2:end,2:end);
%parameters
t=0;
r=0;
q=0;
S0=2772.70;
% take the strike from the data
K = data(2:end,1)*S0;

%creating and initialisation of the price matrix
NK = length(K);
NT = length(T);
Cobs = zeros(NK,NT);
C0 = max(S0-K,0)';
Cobs(:,1) = C0;

%implementation of CObs matrix
for i=1:NK
    for j =1:NT-1
        if (data_vol(i,j) >0)
            Cobs(i,j+1) = BlackScholes(S0,t,data_vol(i,j),K(i),T(j+1),r,q);
        end    
    end
end

% true or false matrix
tf_matrix = data_vol>0;

%Optimization pb
for j = 1:NT-1 
    not_zeros = find((data_vol(:,j)>0));
    dt = T(j+1)-T(j);
    dK = K(2)-K(1);
    opti = @(x) sum(tf_matrix(:,j).*(AH(tf_matrix,j,x,Cobs,dt,dK,K)-Cobs(:,j+1)).^2);
    %inotialization of the optimization pb
    x0 = 0.2*ones(length(NK),1)*S0;
    %optimization
    [X{j},fval] = fminsearch(opti,x0);
    %New value of the call option using Andrasen Huge algo
    NewC = AH(tf_matrix,j,X{j},Cobs,dt,dK,K);
    Cobs(:,j+1) = NewC;
end

IV = NaN(size(data_vol));

for i = 1:NK
    for j = 2:NT
        opti2 = @(sigma) (BlackScholes(S0,t,sigma,K(i),T(j),r,q) - Cobs(i,j))^2;
        [IV(i,j-1),fval(i,j)] = fminsearch(opti2,0.5);
    end
end
% Volatility surface

x = repmat(K,1,NT-1);
y = repmat(T(2:end),NK,1);

%Plot
figure
surf(x,y,IV)
title('Volatility surface')
xlabel('Strikes')
ylabel('Maturities')
zlabel('Volatility')