
function output = AH(tf_matrix,j,x,C,dT,dK,K)
    m = round((tf_matrix(1:end-1,1) + tf_matrix(2:end,1)) / 2);
    NK = length(K);
    kvol = NaN(NK,1);
    k = 1;
    for p = 1:length(m)
        while k < m(p)
            kvol(k) = x(p);
            k = k+1;
        end
        kvol(k:end) = x(end);
    end

    %A
    z = 0.5 * dT/dK^2 * kvol(2:end).^2;
    z(end) = [];                               
    transform = repmat(z,1,3).*[-1 2 -1];
    A = zeros(1,NK);
    for m = 1:NK-2
        A = [A; zeros(1,m-1) transform(m,:) zeros(1,NK-2-m)];
    end
    A = [A; zeros(1,NK)];
    A = A + eye(NK);
    output = A\C(:,j);
end